import Foundation

/// The ONLY layer allowed to produce side effects in Oracle-OS.
///
/// INVARIANTS:
///   - Executor observes and acts, but does NOT commit state
///   - Executor returns ExecutionOutcome with events and artifacts only
///   - CommitCoordinator is the ONLY entity that writes committed state
public actor VerifiedExecutor {
    private let policyEngine: PolicyEngine
    private let commandRouter: CommandRouter
    private let preconditionsValidator: PreconditionsValidator
    private let postconditionsValidator: PostconditionsValidator
    private let snapshotProvider: @Sendable () async -> WorldModelSnapshot

    public init(
        policyEngine: PolicyEngine = .shared,
        commandRouter: CommandRouter = CommandRouter(),
        preconditionsValidator: PreconditionsValidator = PreconditionsValidator(),
        postconditionsValidator: PostconditionsValidator = PostconditionsValidator(),
        snapshotProvider: @escaping @Sendable () async -> WorldModelSnapshot
    ) {
        self.policyEngine = policyEngine
        self.commandRouter = commandRouter
        self.preconditionsValidator = preconditionsValidator
        self.postconditionsValidator = postconditionsValidator
        self.snapshotProvider = snapshotProvider
    }

    /// Execute a validated command and return outcome with events.
    /// IMPORTANT: This does NOT commit state — only returns events for CommitCoordinator.
    public func execute(_ command: Command) async throws -> ExecutionOutcome {
        let started = makeEvent(
            command: command,
            eventType: EventKinds.commandStarted,
            payload: CommandLifecyclePayload(status: "started")
        )

        let snapshot = await snapshotProvider()
        do {
            try preconditionsValidator.validate(command, snapshot: snapshot)
        } catch {
            return failOutcome(
                command: command,
                status: .preconditionFailed,
                reason: error.localizedDescription,
                preconditionsPassed: false,
                policyDecision: "not_evaluated",
                postconditionsPassed: false,
                extraEvents: [started]
            )
        }

        let policyDecision = try policyEngine.validate(command)
        guard policyDecision.allowed else {
            return failOutcome(
                command: command,
                status: .policyBlocked,
                reason: policyDecision.reason ?? "Policy rejected",
                preconditionsPassed: true,
                policyDecision: "blocked",
                postconditionsPassed: false,
                extraEvents: [
                    started,
                    makeEvent(
                        command: command,
                        eventType: EventKinds.policyRejected,
                        payload: CommandLifecyclePayload(status: "blocked", reason: policyDecision.reason ?? "blocked")
                    ),
                ]
            )
        }

        do {
            var outcome = try await commandRouter.execute(command, policyDecision: policyDecision)

            guard try postconditionsValidator.validate(command, outcome: outcome) else {
                return failOutcome(
                    command: command,
                    status: .postconditionFailed,
                    reason: "Postconditions failed",
                    preconditionsPassed: true,
                    policyDecision: "approved",
                    postconditionsPassed: false,
                    extraEvents: [started]
                )
            }

            if outcome.events.isEmpty {
                outcome = ExecutionOutcome(
                    commandID: outcome.commandID,
                    status: outcome.status,
                    observations: outcome.observations,
                    artifacts: outcome.artifacts,
                    events: [
                        started,
                        makeEvent(
                            command: command,
                            eventType: EventKinds.commandSucceeded,
                            payload: CommandLifecyclePayload(status: "success")
                        ),
                    ],
                    verifierReport: outcome.verifierReport
                )
            }
            return outcome
        } catch {
            return failOutcome(
                command: command,
                status: .failed,
                reason: error.localizedDescription,
                preconditionsPassed: true,
                policyDecision: "approved",
                postconditionsPassed: false,
                extraEvents: [started]
            )
        }
    }

    private func failOutcome(
        command: Command,
        status: ExecutionStatus,
        reason: String,
        preconditionsPassed: Bool,
        policyDecision: String,
        postconditionsPassed: Bool,
        extraEvents: [EventEnvelope] = []
    ) -> ExecutionOutcome {
        let report = VerifierReport(
            commandID: command.id,
            preconditionsPassed: preconditionsPassed,
            policyDecision: policyDecision,
            postconditionsPassed: postconditionsPassed,
            notes: [reason]
        )
        var events = extraEvents
        events.append(
            makeEvent(
                command: command,
                eventType: EventKinds.commandFailed,
                payload: CommandLifecyclePayload(status: status.rawValue, reason: reason)
            )
        )
        return ExecutionOutcome(
            commandID: command.id,
            status: status,
            observations: [],
            artifacts: [],
            events: events,
            verifierReport: report
        )
    }

    private func makeEvent<P: Encodable>(
        command: Command,
        eventType: String,
        payload: P
    ) -> EventEnvelope {
        let encodedPayload = (try? OracleJSONCoding.makeEncoder().encode(payload)) ?? Data()
        return EventEnvelope(
            sequenceNumber: 0,
            commandID: command.id,
            intentID: command.metadata.intentID,
            timestamp: Date(),
            eventType: eventType,
            payload: encodedPayload
        )
    }
}
