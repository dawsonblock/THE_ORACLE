import Foundation

public struct RuntimeStateReducer: EventReducer {
    public init() {}

    public func apply(events: [EventEnvelope], to state: inout WorldStateModel) {
        let snapshot = state.snapshot
        var cycleCount = snapshot.cycleCount
        var processNames = snapshot.processNames
        var notes = snapshot.notes

        for event in events {
            let payload = ReducerSupport.dictionary(from: event)

            switch event.eventType {
            case "CommandSucceeded", "CommandFailed":
                cycleCount += 1

            case "PolicyRejected":
                let reason = ReducerSupport.string("reason", in: payload) ?? "policy rejected"
                notes = ReducerSupport.appendUnique(notes, value: reason, limit: 20)

            default:
                break
            }

            if let names = ReducerSupport.stringArray("processNames", in: payload) {
                processNames = ReducerSupport.unique(names)
            } else if let name = ReducerSupport.string("processName", in: payload) {
                processNames = ReducerSupport.appendUnique(processNames, value: name)
            }

            if let router = ReducerSupport.string("router", in: payload), event.eventType == "CommandFailed" {
                notes = ReducerSupport.appendUnique(notes, value: "command failed via \(router)", limit: 20)
            }
        }

        state.replaceCommittedSnapshot(
            snapshot.copy(
                cycleCount: cycleCount,
                processNames: processNames,
                notes: notes
            )
        )
    }
}
