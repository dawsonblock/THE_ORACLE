import Foundation

public struct UIStateReducer: EventReducer {
    public init() {}

    public func apply(events: [EventEnvelope], to state: inout WorldStateModel) {
        let snapshot = state.snapshot
        var activeApplication = snapshot.activeApplication
        var windowTitle = snapshot.windowTitle
        var url = snapshot.url
        var visibleElementCount = snapshot.visibleElementCount
        var modalPresent = snapshot.modalPresent
        var observationHash = snapshot.observationHash

        for event in events {
            let payload = ReducerSupport.dictionary(from: event)

            switch event.eventType {
            case "UIObservationCaptured":
                if let value = ReducerSupport.string("appName", in: payload) ?? ReducerSupport.string("app", in: payload) {
                    activeApplication = value
                }
                if let value = ReducerSupport.string("windowTitle", in: payload) {
                    windowTitle = value
                }
                if let value = ReducerSupport.string("url", in: payload) {
                    url = value
                }
                if let value = ReducerSupport.int("visibleElementCount", in: payload) {
                    visibleElementCount = value
                }
                if let value = ReducerSupport.bool("modalPresent", in: payload) {
                    modalPresent = value
                }
                if let value = ReducerSupport.string("observationHash", in: payload) {
                    observationHash = value
                }

            case "AppFocused":
                activeApplication = ReducerSupport.string("appName", in: payload) ?? ReducerSupport.string("app", in: payload) ?? activeApplication

            case "WindowFocused":
                if let value = ReducerSupport.string("appName", in: payload) ?? ReducerSupport.string("app", in: payload) {
                    activeApplication = value
                }
                if let value = ReducerSupport.string("windowTitle", in: payload) {
                    windowTitle = value
                }

            case "NavigationObserved":
                if let value = ReducerSupport.string("url", in: payload) {
                    url = value
                }
                if let value = ReducerSupport.string("appName", in: payload) ?? ReducerSupport.string("app", in: payload) {
                    activeApplication = value
                }

            default:
                break
            }
        }

        state.replaceCommittedSnapshot(
            snapshot.copy(
                activeApplication: .some(activeApplication),
                windowTitle: .some(windowTitle),
                url: .some(url),
                visibleElementCount: visibleElementCount,
                modalPresent: modalPresent,
                observationHash: .some(observationHash)
            )
        )
    }
}
