import Foundation

public struct ProjectStateReducer: EventReducer {
    public init() {}

    public func apply(events: [EventEnvelope], to state: inout WorldStateModel) {
        let snapshot = state.snapshot
        var repositoryRoot = snapshot.repositoryRoot
        var activeBranch = snapshot.activeBranch
        var isGitDirty = snapshot.isGitDirty
        var openFileCount = snapshot.openFileCount
        var buildSucceeded = snapshot.buildSucceeded
        var failingTestCount = snapshot.failingTestCount

        for event in events {
            let payload = ReducerSupport.dictionary(from: event)

            switch event.eventType {
            case "RepositoryObserved":
                if let value = ReducerSupport.string("repositoryRoot", in: payload) ?? ReducerSupport.string("workspaceRoot", in: payload) {
                    repositoryRoot = value
                }
                if let value = ReducerSupport.string("activeBranch", in: payload) {
                    activeBranch = value
                }
                if let value = ReducerSupport.bool("isGitDirty", in: payload) {
                    isGitDirty = value
                }
                if let value = ReducerSupport.int("openFileCount", in: payload) {
                    openFileCount = value
                }

            case "FileRead":
                if ReducerSupport.string("path", in: payload) != nil {
                    openFileCount = max(openFileCount, 1)
                }

            case "FileModified":
                if ReducerSupport.string("path", in: payload) != nil {
                    isGitDirty = true
                    openFileCount = max(openFileCount, 1)
                }

            case "BuildCompleted":
                if let value = ReducerSupport.bool("succeeded", in: payload) ?? ReducerSupport.bool("buildSucceeded", in: payload) {
                    buildSucceeded = value
                } else if let status = ReducerSupport.string("status", in: payload) {
                    buildSucceeded = (status.lowercased() == "success")
                }

            case "TestsCompleted":
                if let value = ReducerSupport.int("failingTestCount", in: payload) {
                    failingTestCount = value
                } else if let succeeded = ReducerSupport.bool("succeeded", in: payload) {
                    failingTestCount = succeeded ? 0 : failingTestCount
                }

            default:
                break
            }
        }

        state.replaceCommittedSnapshot(
            snapshot.copy(
                repositoryRoot: .some(repositoryRoot),
                activeBranch: .some(activeBranch),
                isGitDirty: isGitDirty,
                openFileCount: openFileCount,
                buildSucceeded: .some(buildSucceeded),
                failingTestCount: .some(failingTestCount)
            )
        )
    }
}
