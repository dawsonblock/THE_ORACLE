Oracle-OS main 40 — unified phases 1 through 4 package

Contents
1. oracle_phases_1_to_4_unified.patch
   Single cumulative patch from the original Oracle-OS-main 40 repo to the final phase-4 state.

2. final_changed_files/
   Final merged versions of every file that changed or was added across phases 1 through 4.
   These are repo-relative paths.

3. phase_patches/
   The original per-phase patch files:
   - oracle_phase1_truth_hardening.patch
   - oracle_phase2_typed_events.patch
   - oracle_phase3_preconditions.patch
   - oracle_phase4_independent_verification.patch

4. phase_file_zips/
   The original per-phase changed-file zip bundles.

Changed files included in final_changed_files/
- Sources/OracleControllerHost/ControllerRuntimeBridge.swift
- Sources/OracleOS/Events/EventKinds.swift
- Sources/OracleOS/Events/EventPayloadDecoder.swift
- Sources/OracleOS/Execution/ExecutionEvidence.swift
- Sources/OracleOS/Execution/ExecutionOutcome.swift
- Sources/OracleOS/Execution/OutcomeVerifier.swift
- Sources/OracleOS/Execution/PostExecutionObserver.swift
- Sources/OracleOS/Execution/PostconditionsValidator.swift
- Sources/OracleOS/Execution/PreconditionsValidator.swift
- Sources/OracleOS/Execution/VerifiedExecutor.swift
- Sources/OracleOS/Execution/Routing/CodeRouter.swift
- Sources/OracleOS/Execution/Routing/CommandRouter.swift
- Sources/OracleOS/Execution/Routing/RoutedExecutionResult.swift
- Sources/OracleOS/Execution/Routing/SystemRouter.swift
- Sources/OracleOS/Execution/Routing/UIRouter.swift
- Sources/OracleOS/MCP/MCPDispatch.swift
- Sources/OracleOS/Runtime/RuntimeOrchestrator.swift
- Sources/OracleOS/State/Reducers/DefaultReducers.swift
- Sources/OracleOS/State/Reducers/MemoryStateReducer.swift
- Sources/OracleOS/State/Reducers/ProjectStateReducer.swift
- Sources/OracleOS/State/Reducers/RuntimeStateReducer.swift
- Sources/OracleOS/State/Reducers/StateReducer.swift
- Sources/OracleOS/State/Reducers/UIStateReducer.swift
- Sources/OracleOS/WorldModel/WorldStateModel.swift
- Tests/OracleOSTests/Governance/ExecutionBoundaryTests.swift
- Tests/OracleOSTests/Governance/RuntimeInvariantTests.swift
- Tests/OracleOSTests/Governance/RuntimeWiringTests.swift
- Tests/OracleOSTests/RuntimeTests/PreconditionIntegrationTests.swift
- Tests/OracleOSTests/RuntimeTests/PostExecutionVerificationTests.swift
