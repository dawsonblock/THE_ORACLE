import Foundation

public struct CommandRouter: @unchecked Sendable {
    private let systemRouter: SystemRouter
    private let uiRouter: UIRouter
    private let codeRouter: CodeRouter

    public init(
        automationHost: AutomationHost? = nil,
        workspaceRunner: WorkspaceRunner? = nil,
        repositoryIndexer: RepositoryIndexer = RepositoryIndexer()
    ) {
        self.systemRouter = SystemRouter(workspaceRunner: workspaceRunner)
        self.uiRouter = UIRouter(automationHost: automationHost)
        self.codeRouter = CodeRouter(
            workspaceRunner: workspaceRunner,
            repositoryIndexer: repositoryIndexer
        )
    }

    public func execute(
        _ command: Command,
        policyDecision: PolicyDecision
    ) async throws -> ExecutionOutcome {
        switch command.type {
        case .system:
            return try await systemRouter.execute(command, policyDecision: policyDecision)
        case .ui:
            return try await uiRouter.execute(command, policyDecision: policyDecision)
        case .code:
            return try await codeRouter.execute(command, policyDecision: policyDecision)
        }
    }

    public static func domain(for command: Command) -> CommandType {
        command.type
    }

    static func successOutcome(
        command: Command,
        observations: [ObservationPayload],
        artifacts: [ArtifactPayload],
        policyDecision: PolicyDecision,
        router: String,
        emittedEvents: [EventEnvelope] = []
    ) -> ExecutionOutcome {
        let lifecycleEvents = [
            makeEvent(
                command: command,
                eventType: EventKinds.commandStarted,
                payload: CommandLifecyclePayload(router: router, status: "started")
            ),
            makeEvent(
                command: command,
                eventType: EventKinds.commandSucceeded,
                payload: CommandLifecyclePayload(router: router, status: "success")
            ),
        ]

        return ExecutionOutcome(
            commandID: command.id,
            status: .success,
            observations: observations,
            artifacts: artifacts,
            events: lifecycleEvents + emittedEvents,
            verifierReport: VerifierReport(
                commandID: command.id,
                preconditionsPassed: true,
                policyDecision: policyDecision.allowed ? "approved" : "blocked",
                postconditionsPassed: true
            )
        )
    }

    static func failureOutcome(
        command: Command,
        reason: String,
        policyDecision: PolicyDecision,
        router: String,
        status: ExecutionStatus = .failed,
        emittedEvents: [EventEnvelope] = []
    ) -> ExecutionOutcome {
        let lifecycleEvents = [
            makeEvent(
                command: command,
                eventType: EventKinds.commandStarted,
                payload: CommandLifecyclePayload(router: router, status: "started")
            ),
            makeEvent(
                command: command,
                eventType: EventKinds.commandFailed,
                payload: CommandLifecyclePayload(router: router, status: status.rawValue, reason: reason)
            ),
        ]

        return ExecutionOutcome(
            commandID: command.id,
            status: status,
            observations: [],
            artifacts: [],
            events: lifecycleEvents + emittedEvents,
            verifierReport: VerifierReport(
                commandID: command.id,
                preconditionsPassed: true,
                policyDecision: policyDecision.allowed ? "approved" : "blocked",
                postconditionsPassed: false,
                notes: [reason]
            )
        )
    }

    static func makeEvent<P: Encodable>(
        command: Command,
        eventType: String,
        payload: P
    ) -> EventEnvelope {
        let encoder = OracleJSONCoding.makeEncoder()
        let encodedPayload = (try? encoder.encode(payload)) ?? Data()
        return EventEnvelope(
            sequenceNumber: 0,
            commandID: command.id,
            intentID: command.metadata.intentID,
            timestamp: Date(),
            eventType: eventType,
            payload: encodedPayload
        )
    }
}
